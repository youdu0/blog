---
author:
  name: "youduo"
date: 2021-06-29
# linktitle: hugogithubpages
type:
- post
- posts
title: hugo + github pages
# eventname: Conference
eventlocation: changsha
weight: 10
---

```bash
wget  https://github.com/gohugoio/hugo/releases/download/v0.84.3/hugo_extended_0.84.3_Linux-64bit.deb
sudo dpkg -i hugo_extended_0.84.3_Linux-64bit.deb

hugo new site blog
cd blog
git init
git submodule add  https://github.com/s4n7h0/hugo-theme-timeline.git themes/timeline

cp themes/timeline/exampleSite/config.toml ./
cp -r themes/timeline/exampleSite/content/ ./

hugo server -D # 看看效果，然后在这个基础上改改

hugo -D

git clone https://github.com/username/username.github.io.git

cd username.github.io
cp ~/blog/public* ./ -rf

git add --all
git commit -m "hugo hosts on github pages"
git push -u origin main

# 备份blog
tar -czf blog.tar.gz ./* # at blog/
git  clone https://github.com/username/backup-repo.git
cd backup-repo
mv blo.tar.gz ./
git add --all
git commit -m "backup blog"
git push -u origin main

# it's done!!!
```
